# Velonika Bot

**Created and maintained by Spark Blaze**

Velonika Bot is an independent WhatsApp group automation project built on the Baileys library. It includes group utilities and the Eclipcium (Ec) fictional virtual currency system, with wallet/bank features and free-play games. Eclipcium has no real-world monetary value.

## Setup and deployment

### Requirements

- Node.js 18 or newer (Node.js 20 LTS is recommended).
- A persistent writable disk for `session/` and `data/`; do not use an ephemeral filesystem for production.
- A WhatsApp account you control, linked using QR or pairing code.
- `ffmpeg` installed on the host for media features, or use the included Docker image.

### Run directly on a server

1. Copy `.env.example` to `.env` and set `OWNER_NUMBER` to the administrator's international WhatsApp number (digits only, no `+`). Keep `.env` private.
2. Install dependencies with `npm install --legacy-peer-deps`.
3. Run `npm run preflight`, `npm test`, and `npm run check:syntax`.
4. Start with `npm start`.
5. By default, scan the QR printed in the terminal from WhatsApp → **Linked Devices** → **Link a Device**. For a headless host, set `BOT_PHONE_NUMBER` to the bot account's international number in `.env` before first launch; the bot will print a pairing code instead.
6. Keep the `session/` directory between restarts. Do not share it or commit it to source control.

### Run with Docker Compose (recommended for consistent hosts)

```bash
cp .env.example .env
# Edit .env; set OWNER_NUMBER before launching.
docker compose up -d --build
docker compose logs -f velonika-bot
```

The Compose file persists `session/`, `data/`, and `temp/` on the host. Pair the account by scanning the QR in the logs, or configure `BOT_PHONE_NUMBER` for pairing-code mode before the first launch. Back up `session/` privately and back up `data/` separately. Never publish session credentials or `.env`.

### Multiple bot instances / multiple WhatsApp numbers

Run a **separate copy/deployment per bot account**, each with its own `.env`, `session/`, `data/`, and `temp/` directories. Set each instance's `BOT_PHONE_NUMBER` only to the account being linked and set `OWNER_NUMBER` to its administrator. Do not scale one Compose service against the same session/data directories: simultaneous processes can corrupt auth state, double-process messages, or overwrite economy data. For example, copy the project to separate folders such as `/opt/velonika-a` and `/opt/velonika-b`, configure each independently, then run `docker compose up -d --build` inside each folder.

### Where the bot can respond

The bot can process messages from groups the linked WhatsApp account has joined and direct chats sent to that account, subject to privacy settings, permissions, connectivity, and the host staying online. Add it to the relevant group; grant group-admin status only if you want to use moderation commands. It cannot access arbitrary groups or deliver messages to arbitrary inboxes just because it is deployed. Use direct messaging only for people who have chosen to contact or receive messages from the bot; do not use it for unsolicited bulk messaging. This project uses third-party WhatsApp Web tooling, not the official WhatsApp Business Platform, and WhatsApp may change or restrict compatibility.

### Troubleshooting

- If QR pairing is wanted, remove/blank `BOT_PHONE_NUMBER`, remove the `--pairing-code` argument, and restart.
- If pairing-code mode is wanted on a non-interactive server, set `BOT_PHONE_NUMBER` before starting.
- If the bot asks to pair after every restart, check that `session/` is persistent and writable by the process/container user.
- If owner commands are unavailable, verify `OWNER_NUMBER` uses digits only and matches the admin's WhatsApp number.
- If the bot disconnects, check logs and network stability; no hosting setup can guarantee uninterrupted WhatsApp service.


## Eclipcium

Eclipcium is a fictional, group-scoped game currency. Balances are not money, cannot be exchanged for real currency, and games are free-play; game outcomes do not deduct a user's existing Ec balance. Back up `data/eclipcium.json` before migrating or resetting a deployment.

## Personal member profiles

Members can customise a persistent profile in groups or private chats with `.setbio`, `.setnickname`, `.setstatus`, `.settitle`, `.setquote`, `.setcolor`, and `.setwebsite`. Use `.profile` or `.profilecard` to view a card, `.profile @member` or `.whois @member` to view another member's public custom fields, `.setprofile` to show the user's current WhatsApp profile picture when WhatsApp privacy settings permit it, and `.resetprofile` to clear your custom fields. Profiles are stored locally in `data/customprofiles.json`; the WhatsApp DP itself is fetched from WhatsApp on request and is not copied into the local database. Only share information you are comfortable displaying in the chat.

## Branding and affiliation

Velonika Bot is an independent project created by Spark Blaze. It is **not an official Google product** and is not affiliated with, sponsored by, or endorsed by Google, WhatsApp, or Meta. WhatsApp connectivity is provided through third-party open-source tooling; use it in accordance with applicable terms and laws.

## Copyright and license

This package is a rebranded and modified derivative of an existing open-source bot project. Rebranding does not erase the copyright in pre-existing code. The original attribution and license obligations are retained in `NOTICE.md` and `LICENSE`; new changes may be credited to Spark Blaze. Please review those files before redistributing this package.

## Owner-only Custom Studio

Use `.cusbot` to open the customization menu. The owner can configure the command prefix (`.setprefix`), bot display name (`.setbotname`), profile photo (`.botdp` replying to an image), About/status (`.setdc`), menu theme/style, sticker metadata, welcome/goodbye text, and saved feature preferences. Settings are persisted in `data/botconfig.json`. Prefix changes apply to command parsing and the help menu; dot commands remain accepted as a recovery path. Prefixes may use 1–3 punctuation/symbol characters (for example `!`, `¥`, `√`, `∆`, `×`, `✓`, `@`, `#`, `~`, or combinations), but not letters, digits, spaces, or a lone dot. Customization commands are checked against the configured owner number / owner list, not group-admin status.

Some saved preferences are configuration values and only affect behavior when the corresponding feature reads them. WhatsApp profile changes require an active session and may be rejected by WhatsApp.


### Owner customization alias
- `.setbotdp` is an alias of `.botdp`; reply to an image with either command to request a bot profile-photo update. The bot must be connected and WhatsApp must permit the profile update.
- `.cusbot` is the owner-only command catalogue. The main `.help` menu separates general, admin, owner, profile, games/currency, media, and fun commands.

### Validation limits
`npm test` and `npm run check:syntax` validate the included automated currency checks and JavaScript syntax. They do not guarantee every live command or WhatsApp-side operation: network APIs, session state, permissions, privacy settings, and host configuration must be tested in the deployed environment. Eclipcium is virtual in-bot currency; its game rewards are free-play and are not real-money gambling.

## Professional help-menu update (release candidate)

The WhatsApp reply help menu now has separate sections: `help`, `general`, `admin`, `profile`, `economy`, `games`, `media`, and `owner`. Examples: `.help profile`, `.help admin`, `.help economy`, and `.help owner`. Configured custom prefixes are normalized by the message handler, so the same section commands can be used with the active prefix.

### Release verification

Run before deployment:

```bash
cp .env.example .env
# Edit .env, then:
npm install --legacy-peer-deps
npm run preflight
npm test
npm run check:syntax
```

The current package passed the Eclipcium test suite (83 canonical game handlers, 98 aliases, 241 test invocations, zero reported failures) and JavaScript syntax checks in the build environment. This does **not** prove every command works against a live WhatsApp account. Before public release, test command routing in both group and private chats, owner/admin permissions, reconnects, profile-picture privacy, third-party service failures, and concurrent economy transactions on a separate test account. Do not describe the release as 100% verified until live integration tests pass.

### Deployment verification scope

Automated checks validate syntax, selected currency behavior, and basic host configuration only. They cannot guarantee that WhatsApp will keep a session linked or that every command works in every group/private chat. Before production, test with an account and group you control, verify owner/admin permissions, test reconnection and persistent storage, and confirm that private-chat replies work as intended.
