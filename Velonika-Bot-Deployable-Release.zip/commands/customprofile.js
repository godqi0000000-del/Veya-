'use strict';
const fs = require('fs');
const path = require('path');
const DB_PATH = path.join(process.cwd(), 'data', 'customprofiles.json');
const COLORS = new Set(['purple','blue','green','red','gold','silver','pink','black','white','cyan']);
function readDB(){ try { const d=JSON.parse(fs.readFileSync(DB_PATH,'utf8')); return d && typeof d==='object' && !Array.isArray(d) ? d : {}; } catch { return {}; } }
function saveDB(db){ fs.mkdirSync(path.dirname(DB_PATH),{recursive:true}); const tmp=DB_PATH+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(db,null,2),{encoding:'utf8',mode:0o600}); fs.renameSync(tmp,DB_PATH); }
function clean(v,max=180){ return String(v??'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,max); }
function jidNumber(jid){ return String(jid||'').split('@')[0].split(':')[0]; }
function mentions(m){ return m?.message?.extendedTextMessage?.contextInfo?.mentionedJid || []; }
function defaults(id,name){ return {nickname:clean(name||jidNumber(id),40),bio:'',status:'Available',title:'Member',quote:'',color:'purple',website:'',updatedAt:new Date().toISOString()}; }
function card(p,target){
 const line=(label,value)=>`│ ${label.padEnd(10)} ${value || '—'}`;
 return `╭━━━〔 ✦ VELONIKA IDENTITY ✦ 〕━━━╮\n│  MEMBER PROFILE  •  ${String(p.color||'purple').toUpperCase()} THEME\n├─────────────────────────────\n${line('NAME',p.nickname)}\n${line('TITLE',p.title||'Member')}\n${line('STATUS',p.status||'Not set')}\n${line('BIO',p.bio||'No bio added')}\n${line('QUOTE',p.quote||'Not set')}\n${line('WEBSITE',p.website||'Not set')}\n├─────────────────────────────\n│ ID: ${jidNumber(target)}\n│ Updated: ${new Date(p.updatedAt||Date.now()).toISOString().slice(0,10)}\n╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n✦ Personal profile • WhatsApp chat edition\nUse .setbio, .setnickname, .setstatus, .settitle, .setquote, .setcolor, .setwebsite to customise.`;
}
async function customProfileCommand(sock,chatId,senderId,message,args){
 const sub=String(args[0]||'profile').toLowerCase();
 const known=new Set(['profile','me','setbio','setnickname','setstatus','settitle','setquote','setcolor','setprofile','profilecard','whois','resetprofile','setwebsite']);
 if(!known.has(sub)) return false;
 const db=readDB(); const tags=mentions(message);
 const target=['profile','profilecard','whois'].includes(sub)&&tags.length?tags[0]:senderId;
 const profile=Object.assign(defaults(target,target===senderId?message?.pushName:''),db[String(target)]||{});
 const reply=async text=>sock.sendMessage(chatId,{text},{quoted:message});
 const value=clean(args.slice(1).join(' '),sub==='setbio'?240:180);
 if(sub==='resetprofile'){ db[senderId]=defaults(senderId,message?.pushName); saveDB(db); return reply('╭━━〔 ♻️ PROFILE RESET 〕━━╮\n│ Your custom fields were cleared.\n│ Your WhatsApp identity is unchanged.\n╰━━━━━━━━━━━━━━━━━━━━━━╯'); }
 const fields={setbio:['bio','Biography',240],setnickname:['nickname','Nickname',40],setstatus:['status','Status',80],settitle:['title','Title',50],setquote:['quote','Quote',120],setwebsite:['website','Website',160]};
 if(fields[sub]){ const [field,label,max]=fields[sub]; const v=clean(args.slice(1).join(' '),max); if(!v)return reply(`╭━━〔 ✎ EDIT PROFILE 〕━━╮\n│ Field: ${label}\n│ Usage: .${sub} <text>\n╰━━━━━━━━━━━━━━━━━━━━━━╯`); if(sub==='setwebsite'&&!/^https?:\/\/\S+\.\S+/i.test(v))return reply('⚠️ Website URL must begin with https:// or http://.'); const own=Object.assign(defaults(senderId,message?.pushName),db[senderId]||{}); own[field]=v; own.updatedAt=new Date().toISOString(); db[senderId]=own; saveDB(db); return reply(`╭━━〔 ✓ PROFILE UPDATED 〕━━╮\n│ ${label}: ${v}\n│ Saved locally and ready to preview.\n│ Preview: .profile\n╰━━━━━━━━━━━━━━━━━━━━━━╯`); }
 if(sub==='setcolor'){ const c=clean(args[1],20).toLowerCase(); if(!COLORS.has(c))return reply('🎨 Available themes: purple, blue, green, red, gold, silver, pink, black, white, cyan.\nExample: .setcolor purple'); profile.color=c; profile.updatedAt=new Date().toISOString(); db[senderId]=profile; saveDB(db); return reply(`🎨 *PROFILE THEME UPDATED*\nSelected theme: ${c}\nPreview: .profile`); }
 if(sub==='setprofile'){
   try { const url=await sock.profilePictureUrl(senderId,'image'); await sock.sendMessage(chatId,{image:{url},caption:`╭━━〔 🪪 WHATSAPP AVATAR 〕━━╮\n│ ${profile.nickname}\n│ Profile picture retrieved from your current WhatsApp DP.\n╰━━━━━━━━━━━━━━━━━━━━━━╯`},{quoted:message}); return true; }
   catch(e){ console.error('[profile dp]',e?.message||e); return reply('⚠️ *PROFILE PICTURE UNAVAILABLE*\nWhatsApp did not provide your DP. Check privacy settings and try again. Your custom profile remains available with .profile.'); }
 }
 if(['profile','me','profilecard','whois'].includes(sub)){
   const text=card(profile,target);
   try { const url=await sock.profilePictureUrl(target,'image'); await sock.sendMessage(chatId,{image:{url},caption:text},{quoted:message}); }
   catch(e){ await reply(text); }
   return true;
 }
 return false;
}
module.exports={customProfileCommand};
