require('dotenv').config();

const settings = {
  packname: 'Velonika Bot',
  author: 'Spark Blaze',
  botName: "Velonika Bot",
  botOwner: 'Spark Blaze', // Your name
  ownerNumber: String(process.env.OWNER_NUMBER || '').replace(/\D/g, ''), // International digits only, e.g. 919876543210
  giphyApiKey: process.env.GIPHY_API_KEY || '',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.7",
  updateZipUrl: "",
};

module.exports = settings;
