# Notices and attribution

Velonika Bot is the rebranded and modified version of an existing open-source WhatsApp bot project.

- Original project attribution: Professor / mruniquehacker (as identified in the upstream project documentation and source headers).
- Velonika Bot rebranding and modifications: Spark Blaze, 2026.
- Third-party dependencies remain under their respective licenses; see each package's license and the dependency metadata.
- Baileys and other third-party projects are not owned by Spark Blaze.

This notice is retained to respect the upstream project's stated MIT-license attribution requirements. It does not imply endorsement by the original author.
